package Controle;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import Modelo.Jogo;

public class AlterarArquivo {
	public static void gravarlista(ArrayList<Jogo> listas) {
		try {
			FileOutputStream arquivoGrav = new FileOutputStream("saida.ser");
			ObjectOutputStream objGravar = new ObjectOutputStream(arquivoGrav);
			objGravar.writeObject(listas);
			objGravar.flush();
			objGravar.close();
			arquivoGrav.flush();
			arquivoGrav.close();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

}