package Controle;

import java.util.ArrayList;
import Modelo.Jogo;
import Visao.TelaIncluir;

public class ControleJogo {
	private ArrayList<Jogo> listaJogo;

	public ControleJogo() {
		listaJogo = new ArrayList<Jogo>();
	}

	public void IncluirJogo(Jogo J) {
		listaJogo.add(J);
	}

	public ArrayList<Jogo> PassaAlista() {
		return this.listaJogo;
	}

}
