package Controle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import Modelo.Jogo;

public class CriarArquivo {
	public static void ManipuladorArquivo(ArrayList<Jogo> listas) {
		ArrayList<Jogo> jogoRecuperado = new ArrayList<Jogo>();
		if (new File("saida.ser").canRead() == true) {
			try {
				FileInputStream arquivoLeitura = new FileInputStream("saida.ser");
				ObjectInputStream objLeitura = new ObjectInputStream(arquivoLeitura);
				jogoRecuperado = (ArrayList<Jogo>) objLeitura.readObject();
				jogoRecuperado.addAll(listas);
				objLeitura.close();
				arquivoLeitura.close();
				FileOutputStream arquivoGrav = new FileOutputStream("saida.ser");
				ObjectOutputStream objGravar = new ObjectOutputStream(arquivoGrav);
				objGravar.writeObject(jogoRecuperado);
				objGravar.close();
				arquivoGrav.flush();
				arquivoGrav.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {

			try {
				FileOutputStream arquivoGrav = new FileOutputStream("saida.ser");
				ObjectOutputStream objGravar = new ObjectOutputStream(arquivoGrav);
				objGravar.writeObject(listas);
				objGravar.flush();
				objGravar.close();
				arquivoGrav.flush();
				arquivoGrav.close();
			}

			catch (Exception e) {
				e.printStackTrace();
			}

		}

		ArrayList<Jogo> lista = jogoRecuperado;

	}

	public static ArrayList<Jogo> retornaLista() {
		ArrayList<Jogo> jogoRecuperado = new ArrayList<Jogo>();
		if (new File("saida.ser").canRead() == true) {
			try {
				FileInputStream arquivoLeitura = new FileInputStream("saida.ser");
				ObjectInputStream objLeitura = new ObjectInputStream(arquivoLeitura);
				jogoRecuperado = (ArrayList<Jogo>) objLeitura.readObject();
				objLeitura.close();
				arquivoLeitura.close();
				return (jogoRecuperado);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;

	}
}