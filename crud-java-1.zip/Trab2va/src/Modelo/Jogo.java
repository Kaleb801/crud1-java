package Modelo;

import java.util.Date;
import java.io.Serializable;

public class Jogo implements Serializable {
	public int id;
	public String nome;
	public String tipo;
	public int tamanho;
	public String dificuldade;
	public String plataforma;

	public Jogo(int id, String nome, String tipo, int tamanho, String dificuldade, String plataforma) {
		super();
		this.id = id;
		this.nome = nome;
		this.tipo = tipo;
		this.tamanho = tamanho;
		this.dificuldade = dificuldade;
		this.plataforma = plataforma;
	}

	public String toString() {
		return "Jogo [" + id + "," + nome + "," + tipo + "," + tamanho + "," + dificuldade + "," + plataforma + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getTamanho() {
		return tamanho;
	}

	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}

	public String getDificuldade() {
		return dificuldade;
	}

	public void setDificuldade(String dificuldade) {
		this.dificuldade = dificuldade;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}

}
