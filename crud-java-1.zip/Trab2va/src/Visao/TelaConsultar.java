package Visao;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;

import Controle.CriarArquivo;
import Modelo.Jogo;
import net.miginfocom.swing.MigLayout;
import java.awt.Color;

public class TelaConsultar extends JFrame {

	private JPanel contentPane;
	private JTable table;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaConsultar frame = new TelaConsultar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TelaConsultar() {
		setBounds(100, 100, 474, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panelTitulo = new JPanel();
		panelTitulo.setBackground(Color.BLACK);
		contentPane.add(panelTitulo, BorderLayout.NORTH);

		JLabel lblJogosCadastrados = new JLabel("Jogos Cadastrados");
		lblJogosCadastrados.setForeground(Color.WHITE);
		lblJogosCadastrados.setFont(new Font("Tahoma", Font.PLAIN, 22));
		panelTitulo.add(lblJogosCadastrados);

		JPanel panelTabela = new JPanel();
		contentPane.add(panelTabela, BorderLayout.CENTER);

		JScrollPane scrollPane = new JScrollPane();
		panelTabela.add(scrollPane);

		ArrayList<Jogo> listas = CriarArquivo.retornaLista();

		DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("Id");
		modelo.addColumn("Nome");
		modelo.addColumn("Tipo");
		modelo.addColumn("Tamanho");
		modelo.addColumn("Dificuldade");
		modelo.addColumn("Plataforma");
		Object colunas[] = new Object[6];
		if (listas.isEmpty()) {
			modelo.addRow(new String[] { "Sem informa��es", "Sem informa��es", "Sem informa��es", "Sem informa��es",
					"Sem informa��es" });
		} else {
			for (int i = 0; i < listas.size(); i++) {
				colunas[0] = listas.get(i).id;
				colunas[1] = listas.get(i).nome;
				colunas[2] = listas.get(i).tipo;
				colunas[3] = listas.get(i).tamanho;
				colunas[3] = colunas[3]+" Horas";
				colunas[4] = listas.get(i).dificuldade;
				colunas[5] = listas.get(i).plataforma;
				modelo.addRow(colunas);

			}

		}
		table = new JTable();
		table.setModel(modelo);

		scrollPane.setViewportView(table);
	}

}
