package Visao;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.util.ArrayList;
import java.util.List;

import Controle.CriarArquivo;
import Controle.ControleJogo;

import java.awt.GridLayout;
import net.miginfocom.swing.MigLayout;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Modelo.Jogo;

public class TelaIncluir extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField textFieldId;
	private JLabel lblNewLabel_1;
	private JTextField textFieldNome;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JTextField textFieldTipo;
	private JTextField textFieldTamanho;
	private JTextField textFieldDificuldade;
	private JTextField textFieldPlataforma;
	private JButton btnNewButton;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaIncluir frame = new TelaIncluir();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TelaIncluir() {
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 5));

		btnNewButton = new JButton("Incluir");
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(SystemColor.controlHighlight);
		panel.add(btnNewButton);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.DARK_GRAY);
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new MigLayout("", "[64px,grow][64px,grow][64px,grow][64px,grow][64px,grow][64px,grow]",
				"[22px][22px][][][][][][][]"));

		lblNewLabel = new JLabel("Id");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBackground(new Color(0, 0, 0));
		panel_1.add(lblNewLabel, "cell 0 0");

		lblNewLabel_1 = new JLabel("Nome");
		lblNewLabel_1.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel_1, "cell 1 0");

		lblNewLabel_2 = new JLabel("Tipo");
		lblNewLabel_2.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel_2, "cell 2 0");

		lblNewLabel_3 = new JLabel("Tamanho");
		lblNewLabel_3.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel_3, "cell 3 0");

		lblNewLabel_4 = new JLabel("Dificuldade");
		lblNewLabel_4.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel_4, "cell 4 0");

		lblNewLabel_5 = new JLabel("Plataforma");
		lblNewLabel_5.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel_5, "cell 5 0");

		textFieldId = new JTextField();
		textFieldId.setForeground(SystemColor.windowBorder);
		panel_1.add(textFieldId, "cell 0 1,growx");
		textFieldId.setColumns(10);

		textFieldNome = new JTextField();
		panel_1.add(textFieldNome, "cell 1 1,growx");
		textFieldNome.setColumns(10);

		textFieldTipo = new JTextField();
		panel_1.add(textFieldTipo, "cell 2 1,growx");
		textFieldTipo.setColumns(10);

		textFieldTamanho = new JTextField();
		panel_1.add(textFieldTamanho, "cell 3 1,growx");
		textFieldTamanho.setColumns(10);

		textFieldDificuldade = new JTextField();
		panel_1.add(textFieldDificuldade, "cell 4 1,growx");
		textFieldDificuldade.setColumns(10);

		textFieldPlataforma = new JTextField();
		panel_1.add(textFieldPlataforma, "cell 5 1,growx");
		textFieldPlataforma.setColumns(10);

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = textFieldId.getText();
				String nome = textFieldNome.getText();
				String tipo = textFieldTipo.getText();
				String tamanho = textFieldTamanho.getText();
				String dificuldade = textFieldDificuldade.getText();
				String plataforma = textFieldPlataforma.getText();
				Integer resultado1 = Integer.valueOf(id);
				Integer resultado2 = Integer.valueOf(tamanho);
				Jogo jogo = new Jogo(resultado1, nome, tipo, resultado2, dificuldade, plataforma);
				c.IncluirJogo(jogo);
				ArrayList<Jogo> lista = c.PassaAlista();
				CriarArquivo.ManipuladorArquivo(lista);
			}
		});

	}

	ControleJogo c = new ControleJogo();

}
