package Visao;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class TelaPrincipal extends JFrame {
	JMenuItem mntmSair;

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TelaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 558, 460);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnArquivo = new JMenu("Arquivo");
		menuBar.add(mnArquivo);

		JMenuItem mntmIncluir = new JMenuItem("Incluir");
		mntmIncluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exibirTelaIncluir();

			}
		});
		mnArquivo.add(mntmIncluir);
		JMenuItem mntmConsultar = new JMenuItem("Consultar");
		mntmConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exibirTelaConsultar();

			}
		});
		mnArquivo.add(mntmConsultar);

		JMenuItem mntmAlterar = new JMenuItem("Alterar/Excluir");
		mntmAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exibirTelaAlterar();

			}
		});
		mnArquivo.add(mntmAlterar);

		JMenuItem mntmSair = new JMenuItem("Sair");
		mntmSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnArquivo.add(mntmSair);

		JMenuItem menuItem = new JMenuItem("");
		menuBar.add(menuItem);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);

		JLabel lblImagem = new JLabel("");
		lblImagem.setIcon(new ImageIcon("Background.jpg"));
		panel.add(lblImagem);
	}

	protected void exibirTelaIncluir() {
		TelaIncluir inserirTela = new TelaIncluir();
		inserirTela.setVisible(true);
	}

	protected void exibirTelaConsultar() {
		TelaConsultar inserirTela = new TelaConsultar();
		inserirTela.setVisible(true);
	}

	protected void exibirTelaAlterar() {
		TelaAlterar_Excluir inserirTela = new TelaAlterar_Excluir();
		inserirTela.setVisible(true);
	}

	protected void exibirTelaExcluir() {
		TelaAlterar_Excluir inserirTela = new TelaAlterar_Excluir();
		inserirTela.setVisible(true);
	}
}
